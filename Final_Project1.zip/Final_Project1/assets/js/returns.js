document.addEventListener('DOMContentLoaded', () => {
    // === Return Modal ===
    const returnButtons = document.querySelectorAll('.btn-return');
    const returnModal = document.getElementById('returnModal');
    const returnClose = returnModal.querySelector('.close');
    const costInput = document.getElementById('modalCostPrice');
    const qtyInput = document.getElementById('modalQuantity');
    const refundInput = document.getElementById('modalRefund');

    returnButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const purchaseId = btn.dataset.purchaseId;
            const productId = btn.dataset.productId;
            const cost = parseFloat(btn.dataset.cost);
            const remaining = btn.dataset.remaining;

            document.getElementById('modalPurchaseId').value = purchaseId;
            document.getElementById('modalProductId').value = productId;
            costInput.value = cost.toFixed(2);
            qtyInput.value = '';
            refundInput.value = '₱0.00';

            qtyInput.setAttribute('max', remaining);
            returnModal.style.display = 'block';
        });
    });

    qtyInput.addEventListener('input', () => {
       const qty = parseInt(qtyInput.value) || 0;
       const cost = parseFloat(costInput.value);
       const refund = qty * cost;
       refundInput.value = `₱${refund.toFixed(2)}`;
    });

    returnClose.onclick = () => returnModal.style.display = 'none';
    window.addEventListener('click', e => {
        if (e.target === returnModal) returnModal.style.display = 'none';
    });

    // === View Details Modal ===
    const viewModal = document.getElementById('viewDetailsModal');
    const viewClose = viewModal.querySelector('.close');
    const viewButtons = document.querySelectorAll('.btn-view');
    const detailsContainer = document.getElementById('detailsContainer');

    viewButtons.forEach(button => {
        button.addEventListener('click', function () {
            const returnId = this.dataset.returnId;
            fetch(`get_return_details.php?return_id=${returnId}`)
                .then(res => res.text())
                .then(data => {
                    detailsContainer.innerHTML = data;
                    viewModal.style.display = 'block';
                })
                .catch(err => {
                    detailsContainer.innerHTML = 'Failed to load details.';
                    console.error(err);
                });
        });
    });

    viewClose.onclick = () => viewModal.style.display = 'none';
    window.addEventListener('click', e => {
        if (e.target === viewModal) viewModal.style.display = 'none';
    });
});
