function openCategoryModal() {
  document.getElementById('categoryModal').style.display = 'block';
  document.getElementById('category-modal-title').textContent = 'Add Category';
  document.getElementById('category-form').reset();
  document.getElementById('category-id').value = '';
}

function closeCategoryModal() {
  document.getElementById('categoryModal').style.display = 'none';
}

function editCategory(id, name) {
  openCategoryModal();
  document.getElementById('category-modal-title').textContent = 'Edit Category';
  document.getElementById('category-id').value = id;
  document.getElementById('category-name').value = name;
}

function deleteCategory(id) {
  if (confirm('Are you sure you want to delete this category?')) {
    window.location.href = 'category.php?delete_category=' + encodeURIComponent(id);
  }
}

window.onclick = function(event) {
  var modal = document.getElementById('categoryModal');
  if (event.target == modal) {
    closeCategoryModal();
  }
}


