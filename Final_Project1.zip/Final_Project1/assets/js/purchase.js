document.addEventListener("DOMContentLoaded", function () {
    const modal = document.getElementById("purchaseModal");
    const openModalBtn = document.getElementById("openModalBtn");
    const closeModalBtn = document.getElementById("closeModalBtn");
    const cancelBtn = document.getElementById("cancelPurchaseBtn");
    const addMoreBtn = document.getElementById("addPurchasesBtn");
    const purchasesContainer = document.getElementById("purchases-container");
    const totalCostSpan = document.getElementById("totalCost");

    function calculateTotal() {
        let total = 0;
        const rows = purchasesContainer.querySelectorAll(".purchases-row");
        rows.forEach(row => {
            const qty = parseFloat(row.querySelector("input[name='quantity[]']").value) || 0;
            const cost = parseFloat(row.querySelector("input[name='cost_price[]']").value) || 0;
            total += qty * cost;
        });
        totalCostSpan.textContent = total.toFixed(2);
    }

    function addRow() {
        const templateSelect = document.getElementById("purchase-template");
        const newRow = document.createElement("div");
        newRow.className = "purchases-row";

        newRow.innerHTML = `
            <select name="products_id[]" required>${templateSelect.innerHTML}</select>
            <input type="number" name="quantity[]" min="1" placeholder="Quantity" required>
            <input type="number" step="0.01" name="cost_price[]" min="0" placeholder="Cost Price" required>
            <button type="button" class="btn-delete" title="Remove">Remove</button>
        `;

        // Events for new row
        newRow.querySelector("input[name='quantity[]']").addEventListener("input", calculateTotal);
        newRow.querySelector("input[name='cost_price[]']").addEventListener("input", calculateTotal);
        newRow.querySelector(".btn-delete").addEventListener("click", function () {
            newRow.remove();
            calculateTotal();
            updateProductOptions();
        });

        newRow.querySelector("select[name='products_id[]']").addEventListener("change", updateProductOptions);

        purchasesContainer.appendChild(newRow);

        updateProductOptions();
    }

    // Add event listeners
    openModalBtn.addEventListener("click", () => modal.style.display = "block");
    closeModalBtn.addEventListener("click", () => modal.style.display = "none");
    cancelBtn.addEventListener("click", () => modal.style.display = "none");
    addMoreBtn.addEventListener("click", addRow);

    // Attach calculation to initial inputs
    document.querySelectorAll("input[name='quantity[]'], input[name='cost_price[]']").forEach(input => {
        input.addEventListener("input", calculateTotal);
    });

    // Remove initial row if needed
    document.querySelectorAll(".btn-delete").forEach(btn => {
        btn.addEventListener("click", function () {
            btn.closest(".purchases-row").remove();
            calculateTotal();
        });
    });

    calculateTotal(); // initial

    // --- Enable POST Button when a purchase row is selected ---
    const postBtn = document.getElementById("postBtn");
    const selectedPurchaseIdInput = document.getElementById("selectedPurchaseId");

    // Safeguard if elements are not present
    if (postBtn && selectedPurchaseIdInput) {
        const purchaseRows = document.querySelectorAll(".purchase-row");

        postBtn.disabled = true; // default state

        purchaseRows.forEach(row => {
            row.addEventListener("click", function () {
                purchaseRows.forEach(r => r.classList.remove("selected"));
                row.classList.add("selected");

                const purchaseId = row.getAttribute("data-id");
                selectedPurchaseIdInput.value = purchaseId;
                postBtn.disabled = false;
            });
        });
    }

    document.getElementById("purchaseForm").addEventListener("submit", function (e) {
    const rows = purchasesContainer.querySelectorAll(".purchases-row");
    if (rows.length === 0) {
        alert("You must add at least one product to proceed.");
        e.preventDefault();
    }
  });


    cancelBtn.addEventListener("click", () => {
        // Close the modal
        modal.style.display = "none";

        // Clear all existing rows
        const rows = purchasesContainer.querySelectorAll(".purchases-row");
        rows.forEach(row => row.remove());

        // Reset total cost display
        totalCostSpan.textContent = "0.00";

        // Reset selected purchase ID and disable post button (if applicable)
        if (selectedPurchaseIdInput) selectedPurchaseIdInput.value = "";
        if (postBtn) postBtn.disabled = true;

        // Add one fresh empty row for new input
        addRow(); // <-- this calls your existing `addRow()` function
    });


    function updateProductOptions() {
        // Collect all selected product values
        const selectedValues = Array.from(document.querySelectorAll('select[name="products_id[]"]'))
            .map(select => select.value)
            .filter(val => val !== "");

        // Update all select elements
        document.querySelectorAll('select[name="products_id[]"]').forEach(select => {
            const currentValue = select.value;

            Array.from(select.options).forEach(option => {
                if (option.value === "") return; // skip placeholder

                // Disable option if it's selected in another select
                if (selectedValues.includes(option.value) && option.value !== currentValue) {
                    option.disabled = true;
                } else {
                    option.disabled = false;
                }
            });
        });
    }

    // Trigger update when a product is selected
    document.addEventListener('change', function(e) {
        if (e.target.matches('select[name="products_id[]"]')) {
            updateProductOptions();
        }
    });



});
