document.addEventListener('DOMContentLoaded', function() {
  const productModal = document.getElementById('productModal');
  const modalForm = document.getElementById('modal-product-form');
  const modalTitle = document.getElementById('modal-title');
  const modalProductId = document.getElementById('modal-product-id');
  const modalProductName = document.getElementById('modal-product-name');
  const modalProductPrice = document.getElementById('modal-product-price');
  const modalProductStock = document.getElementById('modal-product-stock');
  const modalProductCategory = document.getElementById('modal-product-category');
  const modalProductImage = document.getElementById('modal-product-image');
  const imagePreview = document.getElementById('image-preview');
  const closeModalBtn = document.getElementById('closeModal');

  window.resetProductForm = function() {
    modalTitle.textContent = 'Add Product';
    modalForm.action = 'create_product.php';
    modalProductId.value = '';
    modalProductName.value = '';
    modalProductPrice.value = '';
    modalProductStock.value = '';
    modalProductCategory.value = '';
    modalProductImage.value = '';
    imagePreview.style.display = 'none';
    productModal.style.display = 'block';
  };

  window.editProduct = function(id) {
    const row = document.querySelector(`tr[data-id='${id}']`);
    if (!row) return;

    modalTitle.textContent = 'Edit Product';
    modalForm.action = 'update_product.php';
    modalProductId.value = id;
    modalProductName.value = row.getAttribute('data-name');
    modalProductPrice.value = row.getAttribute('data-price');
    modalProductStock.value = row.getAttribute('data-stock');
    modalProductCategory.value = row.getAttribute('data-category');

    const imgFileName = row.getAttribute('data-image');
    if (imgFileName) {
      imagePreview.src = "./assets/images/" + imgFileName;
      imagePreview.style.display = 'inline-block';
    } else {
      imagePreview.style.display = 'none';
    }
    modalProductImage.value = '';
    productModal.style.display = 'block';
  };

  modalProductImage.addEventListener('change', function() {
    const file = this.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = function(e) {
        imagePreview.src = e.target.result;
        imagePreview.style.display = 'inline-block';
      };
      reader.readAsDataURL(file);
    } else {
      imagePreview.style.display = 'none';
    }
  });

  closeModalBtn.onclick = function() {
    productModal.style.display = 'none';
  };

  window.onclick = function(event) {
    if (event.target === productModal) {
      productModal.style.display = 'none';
    }
  };
});