function addToSale(btn) {
    var card = btn.closest('.product-card');
    var pid = card.getAttribute('data-id');
    var name = card.getAttribute('data-name');
    var price = parseFloat(card.getAttribute('data-price'));
    var stock = parseInt(card.getAttribute('data-stock'));
    var img = card.getAttribute('data-image');
    var qtyInput = card.querySelector('.qty-input');
    var qty = parseInt(qtyInput.value);

    if (isNaN(qty) || qty < 1 || qty > stock) {
        alert('Invalid quantity.');
        return;
    }

    // Check if already in table
    var found = false;
    document.querySelectorAll('#sale-items tr').forEach(function(row) {
        if (row.dataset.pid == pid) {
            var qtyCell = row.querySelector('.qty-edit');
            var currentQty = parseInt(qtyCell.value);
            var newQty = currentQty + qty;
            if (newQty > stock) {
                alert('Cannot add more than available stock.');
                found = true;
                return;
            }
            qtyCell.value = newQty;
            row.querySelector('input[name="quantities[]"]').value = newQty;
            row.querySelector('.sale-subtotal').textContent = '₱' + (price * newQty).toFixed(2);
            found = true;
        }
    });

    if (!found) {
        var tr = document.createElement('tr');
        tr.dataset.pid = pid;
        tr.dataset.stock = stock;
        tr.innerHTML = `
            <td>
                <img src="${img}" alt="${name}" style="width:40px;height:40px;object-fit:cover;border-radius:6px;">
            </td>
            <td>
                ${name}<input type="hidden" name="products[]" value="${pid}">
            </td>
            <td>
                <input type="number" class="qty-edit" min="1" max="${stock}" value="${qty}" style="width:60px;">
                <input type="hidden" name="quantities[]" value="${qty}">
            </td>
            <td>
                ${price.toFixed(2)}<input type="hidden" name="prices[]" value="${price}">
            </td>
            <td class="sale-subtotal">
                ₱${(price * qty).toFixed(2)}
            </td>
            <td>
                <button type="button" class="btn-delete">Remove</button>
            </td>
        `;
        document.getElementById('sale-items').appendChild(tr);
    }
    updateTotal();
}

// Remove item from checkout list and update total
document.getElementById('sale-items').addEventListener('click', function(e) {
    if (e.target.classList.contains('btn-delete')) {
        e.target.closest('tr').remove();
        updateTotal();
    }
});

// Update subtotal and total if quantity changes in the checkout list
document.getElementById('sale-items').addEventListener('input', function(e) {
    if (e.target.classList.contains('qty-edit')) {
        var row = e.target.closest('tr');
        var qty = parseInt(e.target.value) || 1;
        var max = parseInt(row.dataset.stock) || 9999;
        var price = parseFloat(row.querySelector('input[name="prices[]"]').value) || 0;
        if (qty < 1) qty = 1;
        if (qty > max) qty = max;
        e.target.value = qty;
        row.querySelector('input[name="quantities[]"]').value = qty;
        row.querySelector('.sale-subtotal').textContent = '₱' + (price * qty).toFixed(2);
        updateTotal();
    }
});

function updateTotal() {
    var total = 0;
    document.querySelectorAll('#sale-items tr').forEach(function(row) {
        var qtyInput = row.querySelector('.qty-edit');
        var qty = qtyInput ? parseInt(qtyInput.value) : 0;
        var price = parseFloat(row.querySelector('input[name="prices[]"]').value) || 0;
        total += qty * price;
    });
    document.getElementById('sale-total').value = total.toFixed(2);
}

// Modal close and print functions
function closeModal() {
    document.getElementById('saleModal').style.display = 'none';
    if (window.history.replaceState) {
        const url = new URL(window.location);
        url.searchParams.delete('success');
        url.searchParams.delete('sale_id');
        window.history.replaceState({}, document.title, url.pathname);
    }
}


// Filter products by category
function filterByCategory() {
    var selected = document.getElementById('categorySelect').value;
    document.querySelectorAll('.product-card').forEach(function(card) {
        if (selected === "" || card.dataset.category === selected) {
            card.style.display = "";
        } else {
            card.style.display = "none";
        }
    });
}

function printReceipt() {
    var printContents = document.getElementById('receipt-area').innerHTML;
    var originalContents = document.body.innerHTML;
    document.body.innerHTML = printContents;
    window.print();
    document.body.innerHTML = originalContents;
}

// Initialize total on page load
updateTotal();
