document.addEventListener('DOMContentLoaded', function() {
  const supplierModal = document.getElementById('supplierModal');
  const modalTitle = document.getElementById('supplier-modal-title');
  const modalForm = document.getElementById('modal-supplier-form');
  const modalSupplierId = document.getElementById('modal-supplier-id');
  const modalSupplierName = document.getElementById('modal-supplier-name');
  const modalSupplierContactPerson = document.getElementById('modal-supplier-contact-person');
  const modalSupplierPhone = document.getElementById('modal-supplier-phone');
  const modalSupplierEmail = document.getElementById('modal-supplier-email');
  const modalSupplierAddress = document.getElementById('modal-supplier-address');
  const closeModalBtn = document.getElementById('closeSupplierModal');

  // Open modal for adding a new supplier
  window.resetSupplierForm = function() {
    modalTitle.textContent = 'Add Supplier';
    modalForm.action = 'create_supplier.php';
    modalSupplierId.value = '';
    modalSupplierName.value = '';
    modalSupplierContactPerson.value = '';
    modalSupplierPhone.value = '';
    modalSupplierEmail.value = '';
    modalSupplierAddress.value = '';
    supplierModal.style.display = 'block';
  };

  // Open modal for editing an existing supplier
  window.editSupplier = function(id) {
    const row = document.querySelector(`tr[data-id='${id}']`);
    if (!row) return;

    modalTitle.textContent = 'Edit Supplier';
    modalForm.action = 'update_supplier.php';
    modalSupplierId.value = id;
    modalSupplierName.value = row.getAttribute('data-name');
    modalSupplierContactPerson.value = row.getAttribute('data-contact_person');
    modalSupplierPhone.value = row.getAttribute('data-phone');
    modalSupplierEmail.value = row.getAttribute('data-email');
    modalSupplierAddress.value = row.getAttribute('data-address');
    supplierModal.style.display = 'block';
  };

  // Close modal when clicking the close button
  closeModalBtn.onclick = function() {
    supplierModal.style.display = 'none';
  };

  // Close modal when clicking outside the modal content
  window.onclick = function(event) {
    if (event.target === supplierModal) {
      supplierModal.style.display = 'none';
    }
  };

    window.onclick = function(event) {
    if (event.target == document.getElementById('supplierModal')) {
      document.getElementById('supplierModal').style.display = 'none';
    }
  };

  // Delete supplier
  window.deleteSupplier = function(id) {
    if (confirm('Are you sure you want to delete this supplier?')) {
      window.location.href = `delete_supplier.php?id=${id}`;
    }
  };
});
