-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 02, 2025 at 09:32 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project02`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(7, 'Totes'),
(8, 'Clutches'),
(9, 'Shoulder Bags'),
(10, 'Crossbody Bags'),
(11, 'Handbags'),
(12, 'coffee');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock` int(11) DEFAULT 0,
  `image` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `category_id` int(11) DEFAULT NULL,
  `supplier_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `stock`, `image`, `created_at`, `category_id`, `supplier_id`) VALUES
(1, 'Quinery Tote Bag', 230.00, 5, '1748484731_quineryToteBag.jpg', '2025-05-29 10:12:11', 7, 2),
(2, 'Prada Net Bags', 2700.00, 0, '1748499047_bag 2.jpg', '2025-05-29 14:10:47', 7, 1),
(3, 'Gucci Tessuto Black ', 5067.40, 10, '1748499114_gucci 3.jpg', '2025-05-29 14:11:54', 8, 4),
(4, 'Gucci Ophidia', 10500.90, 11, '1748499341_gucci 1.jpg', '2025-05-29 14:15:41', 11, 1),
(5, 'Pu Leather Plain', 12560.60, 13, '1748499432_images.jpg', '2025-05-29 14:17:12', 11, 1),
(6, 'Kopiko Black', 15.00, 9, '', '2025-06-02 15:06:55', 12, 4);

-- --------------------------------------------------------

--
-- Table structure for table `purchases`
--

CREATE TABLE `purchases` (
  `id` int(11) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `invoice_number` varchar(100) DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `total_cost` decimal(10,2) DEFAULT NULL,
  `status` enum('pending','posted') DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `purchases`
--

INSERT INTO `purchases` (`id`, `supplier_id`, `user_id`, `invoice_number`, `purchase_date`, `total_cost`, `status`) VALUES
(1, 1, 1, 'INV-0001', '2025-05-31', 2137180.00, 'pending'),
(2, 1, 1, 'INV-0002', '2025-05-31', 2600000.00, 'pending'),
(3, 1, 1, 'INV-0003', '2025-05-31', 1000000.00, 'pending'),
(4, 1, 1, 'INV-0004', '2025-05-31', 10200.00, 'pending'),
(5, 1, 1, 'INV-0005', '2025-05-31', 102000.00, 'pending'),
(6, 1, 1, 'INV-0006', '2025-05-31', 1020002.00, 'pending'),
(7, 1, NULL, 'INV-0007', '2025-05-31', NULL, 'pending'),
(8, 1, NULL, 'INV-0008', '2025-05-31', NULL, 'pending'),
(9, 1, NULL, 'INV-0009', '2025-05-31', NULL, 'posted'),
(10, 1, NULL, 'INV-0010', '2025-05-31', NULL, 'posted'),
(11, 1, 1, 'INV-0011', '2025-05-31', 20400.00, 'posted'),
(12, 1, 1, 'INV-0012', '2025-05-31', 37500.00, 'posted'),
(13, 1, 1, 'INV-0013', '2025-05-31', 36000.00, 'posted'),
(14, 1, 1, 'INV-0014', '2025-05-31', 34500.00, 'posted'),
(15, 1, 1, 'INV-0015', '2025-05-31', 337500.00, 'posted'),
(16, 1, 1, 'INV-0016', '2025-05-31', 110000.00, 'posted'),
(17, 1, 1, 'INV-0017', '2025-05-31', 12500.00, 'pending'),
(18, 1, 1, 'INV-0018', '2025-05-31', 11000.00, 'pending'),
(19, 1, NULL, 'INV-0019', '2025-05-31', NULL, 'pending'),
(20, 1, NULL, 'INV-0020', '2025-05-31', NULL, 'pending'),
(21, 1, NULL, 'INV-0021', '2025-05-31', NULL, 'pending'),
(22, 1, NULL, 'INV-0022', '2025-05-31', NULL, 'pending'),
(23, 1, NULL, 'INV-0023', '2025-05-31', NULL, 'pending'),
(24, 2, NULL, 'INV-0024', '2025-06-01', NULL, 'pending'),
(25, 2, NULL, 'INV-0025', '2025-06-01', NULL, 'pending'),
(26, 1, NULL, 'INV-982926', '2025-06-01', NULL, 'pending'),
(27, 1, NULL, 'INV-982927', '2025-06-01', NULL, 'pending'),
(28, 2, NULL, 'INV-982928', '2025-06-02', NULL, 'pending'),
(29, 2, NULL, 'INV-982929', '2025-06-02', NULL, 'pending'),
(30, 1, NULL, 'INV-982930', '2025-06-02', NULL, 'pending'),
(31, 1, NULL, 'INV-982931', '2025-06-02', NULL, 'pending'),
(32, 4, NULL, 'INV-982932', '2025-06-02', NULL, 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `purchases_details`
--

CREATE TABLE `purchases_details` (
  `id` int(11) NOT NULL,
  `purchase_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `cost_price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `purchases_details`
--

INSERT INTO `purchases_details` (`id`, `purchase_id`, `product_id`, `quantity`, `cost_price`) VALUES
(1, 1, 5, 20, 106859.00),
(2, 2, 3, 30, 20000.00),
(3, 2, 1, 20, 100000.00),
(4, 3, 5, 10, 100000.00),
(5, 4, 5, 1, 10200.00),
(6, 5, 1, 1, 102000.00),
(7, 6, 1, 1, 1020002.00),
(8, 7, 1, 1, 1000010.00),
(9, 8, 1, 2, 103000.00),
(10, 9, 1, 1, 101202.00),
(11, 10, 5, 2, 20000.00),
(12, 11, 1, 2, 10200.00),
(13, 12, 2, 3, 12500.00),
(14, 13, 3, 3, 12000.00),
(15, 14, 4, 3, 11500.00),
(16, 15, 5, 3, 112500.00),
(17, 16, 5, 5, 10500.00),
(18, 16, 4, 5, 11500.00),
(19, 17, 2, 1, 12500.00),
(20, 18, 3, 1, 11000.00),
(21, 19, 3, 1, 10500.00),
(22, 20, 2, 2, 10560.00),
(23, 21, 2, 5, 12560.00),
(24, 22, 3, 2, 20500.00),
(25, 23, 4, 1, 23000.00),
(26, 23, 1, 2, 15000.00),
(27, 24, 1, 5, 10500.00),
(28, 24, 5, 5, 11450.00),
(29, 24, 2, 2, 8560.00),
(30, 25, 5, 5, 12500.00),
(31, 25, 1, 5, 8500.00),
(32, 26, 1, 10, 12500.00),
(33, 27, 1, 5, 15000.00),
(34, 28, 1, 10, 12500.00),
(35, 29, 1, 5, 12500.00),
(36, 30, 5, 5, 11500.00),
(37, 30, 2, 5, 10500.00),
(38, 31, 4, 2, 12500.00),
(39, 32, 6, 50, 5.00),
(40, 32, 3, 5, 1000.00);

-- --------------------------------------------------------

--
-- Table structure for table `returns`
--

CREATE TABLE `returns` (
  `id` int(11) NOT NULL,
  `purchase_id` int(11) NOT NULL,
  `return_date` date DEFAULT NULL,
  `reason` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `returns`
--

INSERT INTO `returns` (`id`, `purchase_id`, `return_date`, `reason`) VALUES
(18, 26, '2025-06-01', 'The bag arrived damaged'),
(19, 26, '2025-06-01', 'has defects'),
(20, 26, '2025-06-01', 'the bag arrived damaged'),
(21, 24, '2025-06-01', 'has damages'),
(22, 24, '2025-06-02', 'the bags arrived damaged'),
(24, 25, '2025-06-02', 'has damage'),
(25, 25, '2025-06-02', 'has damage'),
(26, 25, '2025-06-02', 'has damage'),
(27, 24, '2025-06-02', 'has damage'),
(28, 25, '2025-06-02', 'has damage'),
(30, 28, '2025-06-02', 'the bags arrived damaged'),
(31, 32, '2025-06-02', 'cvcvc'),
(32, 32, '2025-06-02', '35435');

-- --------------------------------------------------------

--
-- Table structure for table `return_details`
--

CREATE TABLE `return_details` (
  `id` int(11) NOT NULL,
  `return_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `refund_amount` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `return_details`
--

INSERT INTO `return_details` (`id`, `return_id`, `product_id`, `quantity`, `refund_amount`) VALUES
(25, 30, 1, 5, 62500.00),
(26, 31, 3, 3, 3000.00),
(27, 32, 3, 2, 2000.00);

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `sale_date` date DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `invoice_number` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `user_id`, `sale_date`, `total`, `invoice_number`) VALUES
(17, 2, '2025-05-30', 10500.90, 'INV-683937cd2aae8'),
(18, 2, '2025-05-30', 10500.90, 'INV-6839255402430'),
(19, 2, '2025-05-30', 5067.40, 'INV-6839255402431'),
(20, 2, '2025-05-30', 82383.20, 'INV-6839255402432'),
(21, 2, '2025-05-31', 101348.00, 'INV-6839255402433'),
(22, 2, '2025-05-31', 377278.20, 'INV-6839255402434'),
(23, 2, '2025-05-31', 10400.00, 'INV-6839255402435'),
(24, 2, '2025-06-01', 106159.00, 'INV-6839255402436'),
(25, 2, '2025-06-02', 30.00, 'INV-6839255402437'),
(26, 2, '2025-06-02', 35652.10, 'INV-6839255402438');

-- --------------------------------------------------------

--
-- Table structure for table `sales_details`
--

CREATE TABLE `sales_details` (
  `id` int(11) NOT NULL,
  `sale_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `selling_price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales_details`
--

INSERT INTO `sales_details` (`id`, `sale_id`, `product_id`, `quantity`, `selling_price`) VALUES
(17, 18, 4, 1, 10500.90),
(18, 19, 3, 1, 5067.40),
(19, 20, 2, 6, 2700.00),
(20, 20, 3, 4, 5067.40),
(21, 20, 4, 4, 10500.90),
(22, 20, 1, 17, 230.00),
(23, 21, 3, 20, 5067.40),
(24, 22, 4, 6, 10500.90),
(25, 22, 2, 6, 2700.00),
(26, 22, 5, 19, 12560.60),
(27, 22, 1, 16, 230.00),
(28, 22, 3, 11, 5067.40),
(29, 23, 2, 3, 2700.00),
(30, 23, 1, 10, 230.00),
(31, 24, 1, 5, 230.00),
(32, 24, 4, 10, 10500.90),
(33, 25, 6, 2, 15.00),
(34, 26, 5, 2, 12560.60),
(35, 26, 4, 1, 10500.90),
(36, 26, 6, 2, 15.00);

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `name`, `contact_person`, `phone`, `email`, `address`) VALUES
(1, 'EcoTote Suppliers Inc.', 'Maria Santos', '09171234567', 'contact@ecotote.com', '123 Eco St.'),
(2, 'MetroBag Supply Co.', 'Angela Ramirez', '0917 555 1234', 'angela@metrobags.com', '3rd Floor, Ayala Ave.'),
(4, 'BMM Branch 2', 'Bryant', '43234', 'bmm@gmail.com', 'cebu');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(20) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `created_at`) VALUES
(1, 'admin', '$2y$10$/bU0IGPgULkFcnHxlezEseW8P7a4pJ94j851p7vqR/hr32d4kBZO2', 'admin', '2025-05-29 09:35:40'),
(2, 'cashier', '$2y$10$KrIehKQG0dPhov5iUQdEH.rt4IxkGQ85bjSsb6PE1b8nAgMi4nH6.', 'cashier', '2025-05-29 09:35:40'),
(4, 'renz', '$2y$10$46yc3QtPccq656NmBH6FROArlmuN3bfr9WRDBqMV/bDR7Im23pgXm', 'cashier', '2025-06-02 15:04:53'),
(5, 'percy', '$2y$10$7ECYBwrhs/Olb62Algv2Beh4o1jtDmr.WzNyYVTdVmZgEKMMVz57a', 'admin', '2025-06-02 15:05:07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `purchases`
--
ALTER TABLE `purchases`
  ADD PRIMARY KEY (`id`),
  ADD KEY `supplier_id` (`supplier_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `purchases_details`
--
ALTER TABLE `purchases_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `purchase_id` (`purchase_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `returns`
--
ALTER TABLE `returns`
  ADD PRIMARY KEY (`id`),
  ADD KEY `returns_fk_purchase` (`purchase_id`);

--
-- Indexes for table `return_details`
--
ALTER TABLE `return_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `return_details_fk_return` (`return_id`),
  ADD KEY `return_details_fk_product` (`product_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `sales_details`
--
ALTER TABLE `sales_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sale_id` (`sale_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `purchases`
--
ALTER TABLE `purchases`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `purchases_details`
--
ALTER TABLE `purchases_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `returns`
--
ALTER TABLE `returns`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `return_details`
--
ALTER TABLE `return_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `sales_details`
--
ALTER TABLE `sales_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`);

--
-- Constraints for table `purchases`
--
ALTER TABLE `purchases`
  ADD CONSTRAINT `purchases_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`),
  ADD CONSTRAINT `purchases_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `purchases_details`
--
ALTER TABLE `purchases_details`
  ADD CONSTRAINT `purchases_details_ibfk_1` FOREIGN KEY (`purchase_id`) REFERENCES `purchases` (`id`),
  ADD CONSTRAINT `purchases_details_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `returns`
--
ALTER TABLE `returns`
  ADD CONSTRAINT `returns_fk_purchase` FOREIGN KEY (`purchase_id`) REFERENCES `purchases` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `return_details`
--
ALTER TABLE `return_details`
  ADD CONSTRAINT `return_details_fk_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `return_details_fk_return` FOREIGN KEY (`return_id`) REFERENCES `returns` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `return_details_ibfk_1` FOREIGN KEY (`return_id`) REFERENCES `returns` (`id`),
  ADD CONSTRAINT `return_details_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `sales_details`
--
ALTER TABLE `sales_details`
  ADD CONSTRAINT `sales_details_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`),
  ADD CONSTRAINT `sales_details_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
